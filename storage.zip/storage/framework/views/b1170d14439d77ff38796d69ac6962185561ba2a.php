


<?php $__env->startSection('content'); ?>
<div class="page-content bg-white">
<div class="page-banner ovbl-dark" style="background-image:url(<?php echo e(asset('images/banner/banner2.jpg')); ?>);">
    <div class="container">
        <div class="page-banner-entry">
          <br/>
          <br/>

 </div>
    </div>
</div>
<!-- Breadcrumb row -->
<div class="breadcrumb-row">
<div class="container">
<ul class="list-inline">
  <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
  <li>All Blogs</li>
</ul>
</div>
</div>


<div class="content-block">
<div class="section-area section-sp1">
<div class="container">
 <div class="row">
   <!-- Left part start -->
   <div class="col-lg-8">
     <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <div class="blog-post blog-md clearfix">
       <div class="ttr-post-media">
         <a href="#"><img src="<?php echo e(asset('storage/blogs/' .$row->blogs_image)); ?>" alt=""></a>
       </div>
       <div class="ttr-post-info">
         <ul class="media-post">
           <li><a href="<?php echo e(url('blogs_details/'.$row->id.'/'.$row->blogs_slug)); ?>"><i class="fa fa-calendar"></i><?php echo e($row->created_at); ?></a></li>
           <!--<li><a href="#"><i class="fa fa-user"></i>By William</a></li>-->
         </ul>
         <h5 class="post-title"><a href="<?php echo e(url('blogs_details/'.$row->id.'/'.$row->blogs_slug)); ?>"><?php echo e($row->blogs_title); ?></h5>
         <p><?php echo e($row->short_description); ?></p>
         <div class="post-extra">
           <a href="<?php echo e(url('blogs_details/'.$row->id.'/'.$row->blogs_slug)); ?>" class="btn-link">READ MORE</a>
          <!-- <a href="#" class="comments-bx"><i class="fa fa-comments-o"></i>05 Comment</a>-->
         </div>
       </div>
     </div>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <!-- Pagination start -->
     <div class="col-lg-12 m-b20">

         <?php echo e($data->links('frontend.partials.pagination')); ?>


     </div>
     <!-- Pagination END -->
   </div>
   <!-- Left part END -->
   <!-- Side bar start -->
   <div class="col-lg-4 sticky-top">
     <aside class="side-bar sticky-top">
       <div class="widget">
         <h6 class="widget-title">Search</h6>
         <div class="search-bx style-1">
           <form role="search" method="post">
             <div class="input-group">
               <input name="text" class="form-control" placeholder="Enter your keywords..." type="text">
               <span class="input-group-btn">
                 <button type="submit" class="fa fa-search text-primary"></button>
               </span>
             </div>
           </form>
         </div>
       </div>
       <div class="widget recent-posts-entry">
         <h6 class="widget-title">Recent Posts</h6>
         <div class="widget-post-bx">
           <?php $__currentLoopData = $lts_blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="widget-post clearfix">
             <div class="ttr-post-media"> <img src="<?php echo e(asset('storage/blogs/' .$row->blogs_image)); ?>" width="200" height="143" alt=""> </div>
             <div class="ttr-post-info">
               <div class="ttr-post-header">
                 <h6 class="post-title"><a href="<?php echo e(url('blogs_details/'.$row->id.'/'.$row->blogs_slug)); ?>"><?php echo e($row->blogs_title); ?></a></h6>
               </div>
               <ul class="media-post">
                 <li><a href="#"><i class="fa fa-calendar"></i><?php echo e($row->created_at); ?></a></li>

               </ul>
             </div>
           </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

         </div>
       </div>

       <div class="widget widget_gallery gallery-grid-4">
         <h6 class="widget-title">Our Gallery</h6>
         <ul>
           <li><a href="<?php echo e(asset('images/gallery/1.jpg')); ?>" class="magnific-anchor"><img src="<?php echo e(asset('images/gallery/1.jpg')); ?>" alt=""></a></li>
           <li><a href="<?php echo e(asset('images/gallery/2.jpg')); ?>" class="magnific-anchor"><img src="<?php echo e(asset('images/gallery/2.jpg')); ?>" alt=""></a></li>
           <li><a href="<?php echo e(asset('images/gallery/3.jpg')); ?>" class="magnific-anchor"><img src="<?php echo e(asset('images/gallery/3.jpg')); ?>" alt=""></a></li>
           <li><a href="<?php echo e(asset('images/gallery/4.jpg')); ?>" class="magnific-anchor"><img src="<?php echo e(asset('images/gallery/4.jpg')); ?>" alt=""></a></li>
           <li><a href="<?php echo e(asset('images/gallery/5.jpg')); ?>" class="magnific-anchor"><img src="<?php echo e(asset('images/gallery/5.jpg')); ?>" alt=""></a></li>
           <li><a href="<?php echo e(asset('images/gallery/6.jpg')); ?>" class="magnific-anchor"><img src="<?php echo e(asset('images/gallery/6.jpg')); ?>" alt=""></a></li>
         </ul>
       </div>
      <!-- <div class="widget widget_tag_cloud">
         <h6 class="widget-title">Tags</h6>
         <div class="tagcloud">
           <a href="#">Design</a>
           <a href="#">User interface</a>
           <a href="#">SEO</a>
           <a href="#">WordPress</a>
           <a href="#">Development</a>
           <a href="#">Joomla</a>
           <a href="#">Design</a>
           <a href="#">User interface</a>
           <a href="#">SEO</a>
           <a href="#">WordPress</a>
           <a href="#">Development</a>
           <a href="#">Joomla</a>
           <a href="#">Design</a>
           <a href="#">User interface</a>
           <a href="#">SEO</a>
           <a href="#">WordPress</a>
           <a href="#">Development</a>
           <a href="#">Joomla</a>
         </div>
       </div>-->
     </aside>
   </div>
   <!-- Side bar END -->
 </div>
</div>
</div>
</div>








</div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\globalskills.com.bd\resources\views/frontend/pages/all_blogs.blade.php ENDPATH**/ ?>