


<?php $__env->startSection('admin_dashboard_content'); ?>

<div class="db-breadcrumb">
  <h4 class="breadcrumb-title">Course Details</h4>
  <ul class="db-breadcrumb-list">
    <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-home"></i>Home</a></li>
    <li><?php echo e($course->course_title); ?> </li>
  </ul>
</div>


<div class="row match-height">
  <!-- Base Nav starts -->
  <div class="col-md-12 col-sm-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title"><?php echo e($course->course_title); ?></h4>
      </div>
      <div class="card-body">

        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link active" href="/admin/home/courses/course_details/course_info/<?php echo e($course->id); ?>">Course Info</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="/admin/home/courses/course_details/course_curricullum/<?php echo e($course->id); ?>">Course Curricullum</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="javascript:void(0);">Media</a>
          </li>
            <a class="btn btn-primary" href="#" data-toggle="modal" data-target="#CourseDetailsAddModal"><i class="fas fa-plus-circle"></i></a>
            <?php echo $__env->make('backend.modals.course_details_addmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </ul>
      </div>
    </div>
  </div>
  <!-- Base Nav ends -->


</div>



















<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views//backend/pages/courses/course_overviews.blade.php ENDPATH**/ ?>