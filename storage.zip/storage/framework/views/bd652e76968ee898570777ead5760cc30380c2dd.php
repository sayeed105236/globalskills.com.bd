

<?php $__env->startSection('content'); ?>

    <div class="page-banner ovbl-dark" style="background-image:url(<?php echo e(asset('images/banner/banner2.jpg')); ?>);">
        <div class="container">
            <div class="page-banner-entry">
                <br/>
                <br/>
            </div>
        </div>
    </div>

    <!-- Breadcrumb row -->
    <div class="breadcrumb-row">
        <div class="container">
            <ul class="list-inline">
                <li><a href="<?php echo e(route('course_details')); ?>">Home</a></li>
                <li><a href="#">Cart</a></li>

            </ul>
        </div>
    </div>
    <br>
    <br>

    <div class="container">
        <?php if(Session::has('cart_deleted')): ?>
            <div class="alert alert-danger" role="alert">
                <div class="alert-body">
                    <?php echo e(Session::get('cart_deleted')); ?>

                </div>
            </div>
        <?php endif; ?>

        <div class="row" id="table-hover-animation">
            <div class="col-6">
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <div class="col">
                                <h4 class="card-title" style="color:#ca2128; text-transform:uppercase;">Cart <i
                                        class="fa fa-cart-arrow-down fa-2x"></i></h4>
                            </div>
                            <div class="color">

                            </div>
                        </div>
                    </div>

                    <div class="table table-responsive">
                        <table id="tableContent" class="table table-hover-animation">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Course Name</th>
                                <th>Image</th>
                                <th>Category</th>
                                <th>Regular Price</th>
                                <th>Sale Price</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            $price = 0;
                            ?>
                            <?php $__currentLoopData = App\Models\Cart::totalCarts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($loop->index+1); ?>

                                    </td>
                                    <td>
                                        <span class="font-weight-bold"><a
                                                href="home/course_details/<?php echo e($row->course->id); ?>"><?php echo e($row->course->course_title); ?></a></span>
                                    </td>
                                    <td><img src="<?php echo e(asset('storage/courses/' .$row->course->course_image)); ?>" alt="image"
                                             height="50"
                                             width="50"/></td>
                                    <td><?php echo e($row->course->course_category->mcategory_title); ?></td>
                                    <td>
                                        <del><?php echo e($row->course->regular_price); ?>৳</del>

                                    </td>
                                    <td><?php echo e($row->course->sale_price); ?>৳</td>

                                    <td>
                                        <?php
                                        if ($row->course->sale_price > 0) {
                                            $price += $row->course->sale_price;
                                         } else {
                                            $price += $row->course->regular_price;
                                        }

                                        ?>
                                        <a id="delete" href="/carts/delete/<?php echo e($row->id); ?>"><i class="fa fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>


                    </div>

                </div>
                <hr>
                <?php $__currentLoopData = App\Models\Cart::totalCarts(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($row->course->id == 15): ?>


                <div class="widget recent-posts-entry widget-courses">
                                  <h5 class="widget-title style-1"></h5>
                                  <div class="widget-post-bx">

                                      <div class="widget-post clearfix">
                                          <div class="ttr-post-media"> <img src="<?php echo e(asset('storage/courses/' .$row->course->course_image)); ?>" alt="image"
                                                   height="50"
                                                   width="50"/> </div>
                                          <div class="ttr-post-info">
                                              <div class="ttr-post-header">
                                                  <h6 class="post-title"><a href="#"> Add on Take 2</a></h6>
                                              </div>
                                              <h6>Take2 gives you a second chance at retaking this examination, at a fixed, attractive price.</h6>
                                              <div class="ttr-post-meta">
                                                <ul>




                                                    <li class="price">

                                                      <h5 style="color:#ca2128;">8999৳</h5>
                                                    </li>
                                                    <li class="price">

                                                       <form class="hidden" action="<?php echo e(route('add-carts')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php
                                                        $take2= App\Models\Course::where('id','20')->get()->first();
                                                        //dd($take2);
                                                         ?>
                                                        <input type="hidden" name="course_id" value="<?php echo e($take2->id); ?>">

                                                        <button  class="btn btn-sm"><i class="fa fa-check-circle"> Add To Cart</i></button>

                                                      </form>
                                                    </li>


                                                </ul>
                                              </div>
                                          </div>
                                      </div>


                                  </div>
                              </div>

    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="col-6">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" style="color:#ca2128; text-transform:uppercase;">Total</h4>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-hover-animation">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th></th>
                                    <th>Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <span class="font-weight-bold">Course Price</span>
                                    </td>
                                    <td></td>
                                    <td><?php echo e($price); ?>৳</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="font-weight-bold">Tax(10%)</span>
                                    </td>
                                    <td></td>
                                    <td><?php echo e(($price*10)/100); ?>৳</td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="font-weight-bold">Vat(15%)</span>
                                    </td>
                                    <td></td>
                                    <td>
                                        <?php
                                        $total_price = 0;
                                        $total_price_vat = 0;
                                        $total_price = ($price + (($price * 10) / 100));
                                        $total_price_vat = ($total_price * 15) / 100;
                                        $total = $total_price + $total_price_vat;
                                        ?>
                                        <?php echo e($total_price_vat); ?>৳
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span class="font-weight-bold" style="color:#ca2128; text-transform:uppercase;">Total</span>
                                    </td>
                                    <td>=</td>
                                    <td class="font-weight-bold" style="color:#ca2128; text-transform:uppercase;"><?php echo e($total); ?>

                                        ৳
                                    </td>

                                </tr>

                            </tbody>
                        </table>
                    </div>

                </div>
                <br>

                <form id="paymentform" class="hidden" action="<?php echo e(route('payment')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="amount" value="<?php echo e(isset($total)?$total:''); ?>">
                    <input type="hidden" name="email" value="<?php echo e(isset(Auth::user()->email)?Auth::user()->email:''); ?>">
                    <input type="hidden" name="name" value="<?php echo e(isset(Auth::user()->name)?Auth::user()->name:''); ?>">
                    <input type="hidden" name="phone" value="<?php echo e(isset(Auth::user()->phone)?Auth::user()->phone:''); ?>">

                    <?php if($total > 0 ): ?>
                        <button type="submit" class="text-center btn float-right">Procceed To Payment</button>
                    <?php else: ?>
                        <button type="submit" class="text-center btn float-right" disabled >Procceed To Payment</button>
                    <?php endif; ?>

                </form>
            </div>


        </div>
    </div>

    <br>
    <br>
    <?php $__env->startPush('scripts'); ?>
        <script type="text/javascript">
            //$('#tableContent td:nth-child(2)').each(function(index, tr) {
            //$(tr).find('td').each (function (index, td) {
            //  console.log(index, tr)
            //});
            //});
            $(function () {
                //use the :nth-child selector to get second element
                //iterate with .each()
                var name = [];
                $('#tableContent  td:nth-child(2)').each(function (index, element) {
                    //var name = $(element).text();
                    var arr2 = $.trim($(element).text());
                    name.push(arr2);


                });
                $('#paymentform').append('<input type="hidden" name="course_title" value=' + name + '>');

            });

        </script>
    <?php $__env->stopPush(); ?>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\globalskills.com.bd\resources\views/frontend/users/cart.blade.php ENDPATH**/ ?>