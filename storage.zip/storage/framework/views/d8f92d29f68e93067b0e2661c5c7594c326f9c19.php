<div class="top-bar">
  <div class="container">
    <div class="row d-flex justify-content-between">
      <div class="topbar-left">
        <ul>
          <li><a href="<?php echo e(route('faq')); ?>"><i class="fa fa-question-circle"></i>Ask a Question</a></li>
          <li><a href="javascript:;"><i class="fa fa-envelope-o"></i>info@globalskills.com.bd</a></li>
           <li><a href="javascript:;"><i class="fa fa-mobile"></i>+8801766343434</a></li>
          <li>
            <?php if(Session::has('cart_added')): ?>
            <div class="alert alert-success" role="alert">

              <div class="alert-body">
                <?php echo e(Session::get('cart_added')); ?>

              </div>
            </div>


            <?php endif; ?>

          </li>
        </ul>
      </div>
      <div class="topbar-right">
        <ul>

          <?php if(auth()->guard()->guest()): ?>
              <?php if(Route::has('login')): ?>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                  </li>
              <?php endif; ?>

              <?php if(Route::has('register')): ?>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                  </li>
              <?php endif; ?>
          <?php else: ?>
              <li class="nav-item">
                <?php echo e(Auth::user()->name); ?>




              </li>
              <li><a class="btn btn-light" href="<?php echo e(route('user_profile')); ?>">Dashboard</a></li>

              <li>
                  <a href="<?php echo e(route('logout')); ?>" class="btn btn-primary" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">Logout</a>
                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                      <?php echo csrf_field(); ?>
                  </form>
              </li>

          <?php endif; ?>
        </ul>
      </div>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views/frontend/partials/topbar.blade.php ENDPATH**/ ?>