


<?php $__env->startSection('content'); ?>

<!-- Content -->
  <!-- Main Slider -->
<?php echo $__env->make('frontend.content.sliders', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Main Slider -->
<div class="content-block">

  <!-- Our Services -->
  <?php echo $__env->make('frontend.content.inner_service', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- E-learning Courses -->
  <?php echo $__env->make('frontend.content.e-learning', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- E-learning Courses END -->

  <!-- Classroom -->
  <?php echo $__env->make('frontend.content.classroom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Classroom -->
  <?php echo $__env->make('frontend.content.mocktest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!--<?php echo $__env->make('frontend.content.training_without_exam', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>-->
  <?php echo $__env->make('frontend.content.accreditation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Mock Test -->

  <br>
  <br>

  <!-- Mock Test -->

  <!-- Form -->
  <?php echo $__env->make('frontend.content.overview_banner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Form END -->
  <?php echo $__env->make('frontend.content.events', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <!-- Testimonials -->


  <!-- Testimonials END -->

  <!-- Recent News -->
  <?php echo $__env->make('frontend.content.recent_news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <br><br>

  <!-- Recent News End -->


    </div>
<!-- contact area END -->

<!-- Content END-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\globalskills.com.bd\resources\views/frontend/pages/index.blade.php ENDPATH**/ ?>