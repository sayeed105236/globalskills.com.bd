<div class="section-area section-sp2 popular-courses-bx">
          <div class="container">
    <div class="row">
      <div class="col-md-12 heading-bx left">
        <?php
        $courses = App\Models\Course::all();

         ?>
         <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

         <?php if($row->id==1): ?>


        <h2 class="title-head">Training Without Exam <span>Courses</span></h2>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
    <div class="row">

    <div class="courses-carousel owl-carousel owl-btn-1 col-12 p-lr0">

      <?php
      $courses = App\Models\Course::all();

       ?>
      <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($row->status==1): ?>
      <div class="item">
        <div class="cours-bx">
          <div class="action-box">
            <img src="<?php echo e(asset("storage/courses/$row->course_image")); ?>" alt="" height="420"
            width="700">

            <form class="hidden" action="<?php echo e(route('add-carts')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="course_id" value="<?php echo e($row->id); ?>">

              <button  class="btn">Add to Cart</button>
            </form>
          </div>
          <div class="info-bx text-center">
            <h5><a href="home/course_details/<?php echo e($row->id); ?>"><?php echo e($row->course_title); ?></a></h5>
            <span><?php echo e($row->course_category->mcategory_title); ?></span>
          </div>
          <div class="cours-more-info">
            <div class="review">
              <span>Review</span>
              <ul class="cours-star">
                <li class="active"><i class="fa fa-star"></i></li>
                <li class="active"><i class="fa fa-star"></i></li>
                <li class="active"><i class="fa fa-star"></i></li>
                <li class="active"><i class="fa fa-star"></i></li>
                <li class="active"><i class="fa fa-star"></i></li>

              </ul>
            </div>
            <div class="price">
            <h6>Training Fee</h6>
              <h5><?php echo e($row->sale_price); ?>৳</h5>
            </div>
          </div>
        </div>
      </div>
      <?php endif; ?>


      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    </div>

  </div>
</div>

<div class="text-center">
  <a href="<?php echo e(route('courses')); ?>" class="btn">View All</a>
</div>
<?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views/frontend/content/training_without_exam.blade.php ENDPATH**/ ?>