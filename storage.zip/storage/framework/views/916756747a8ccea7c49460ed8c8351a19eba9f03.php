
<?php $__env->startSection('admin_dashboard_content'); ?>

<div class="container-fluid">
  <div class="db-breadcrumb">
    <h4 class="breadcrumb-title">Users</h4>
    <ul class="db-breadcrumb-list">
      <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-home"></i>Home</a></li>
      <li>User</li>
    </ul>
  </div>
  <?php if(Session::has('user_deleted')): ?>
  <div class="alert alert-danger" role="alert">

    <div class="alert-body">
      <?php echo e(Session::get('user_deleted')); ?>

    </div>
  </div>
  <?php endif; ?>
  <!-- Card -->
  <div class="row" id="basic-table">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Users</h4>
       <a href="#" class="btn btn-success" data-toggle="modal" data-target="#"><i class="fas fa-plus"></i></a>
        </div>

        <div class="table table-responsive">
          <table id="user_list" class="table table-bordered">
            <thead>
              <tr>
                <th class="wd-10p">Id</th>
                <th class="wd-10p">User Name</th>

                <th class="wd-10p">Email</th>
                <th class="wd-10p">Phone Number</th>
                <th class="wd-10p">Role</th>
                <th class="wd-5p">Enrollment</th>
                <th class="wd-5p">Created At</th>
                <th class="wd-10p">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td><?php echo e($row->id); ?></td>
                <td class="user_name">
                    <?php echo e($row->name); ?>


                </td>

                <td>
                    <?php echo e($row->email); ?>

                </td>
                <td>
                    0<?php echo e($row->phone); ?>

                </td>
                <td>
                  <?php if($row->is_admin==1): ?>
                  Admin
                  <?php else: ?>
                  User
                  <?php endif; ?>


                </td>

                <td>
                    <?php if(count($row->user_enrollments) > 0): ?>
                        <?php $__currentLoopData = $row->user_enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge bg-warning text-dark"><?php echo e($enroll->course->course_title); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </td>
                <td><?php echo e($row->created_at); ?></td>

                <td>
                  <a href="#"><i class="fas fa-edit"></i></a>
                  <a id="delete" href="/admin/home/users/delete/<?php echo e($row->id); ?>"><i class="fas fa-trash"></i></a>
                  <a type="button" id="<?php echo e($row->id); ?>" class="addCourse"><i class="fab fa-accessible-icon"></i></a>

                </td>

              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

    <!-- Modal -->
    <?php echo $__env->make('backend.modals.enroll', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<style>
    .btn:active, .btn:hover, .btn:focus, .active > .btn {
        background-color: #d8a409;
         color: #000000;
    }
</style>
<?php $__env->startPush('scripts'); ?>
<script>
  $(function(){
    'use strict';

    $('#user_list').DataTable({
      responsive: false,
      language: {
        searchPlaceholder: 'Search...',
        sSearch: '',
        lengthMenu: '_MENU_ ',
      }
    });
  })

  $(document).off('click','.addCourse').on('click', '.addCourse', function () {

      var user_id = $(this).attr('id');
      var $row = $(this).closest("tr");    // Find the row
      var $text = $row.find(".user_name").text(); // Find the text

      $('#modalTitle').html('Enroll a Course to '+$text);
      $('#addCourseModal').modal('show');
      $('#user_id').val(user_id)
  })

  function coursePrice(){
      var course_id = $('#course_id').val();
      if ((course_id == null || course_id == 0)) return;

      $.ajax({
          type: "GET",
          url: '<?php echo e(route('get.product-price')); ?>',
          //dataType: 'json',
          data: {
              "_token": "<?php echo e(csrf_token()); ?>",'course_id':course_id
          },

          success: function (response) {
            console.log(response)
              var obj = jQuery.parseJSON(response);
              console.log(obj);
              console.log(obj.regular_price);

              $('#regular_price').val(obj.regular_price);

          },
          error: function () {
          }
      });
  }
  //clear modal form data
  $('#addCourseModal').on('hidden.bs.modal', function () {
      $(this).find('form').trigger('reset');
      $('#course_id').val('');
  })

  $('#course_enroll').on('submit', function(event){
      event.preventDefault();

      $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });

      $.ajax({
          type    : "post",
          url: '<?php echo e(route("enroll-course.store")); ?>',
          data: $('#course_enroll').serialize(),
          success : function (response) {

              //$('#addCourseModal').modal('hide');

             /* $('#assetization-list-new-table').dataTable().fnDestroy();
              $('#assetization-list-assetized-table').dataTable().fnDestroy();
              $('#wip-new-table').dataTable().fnDestroy();

              AssetizationListNew(asset_id, po_no);
              AssetizationListAssetized(asset_id, po_no);
              newWip(asset_id, po_no);*/
              location.reload();

          },
          error : function (error_response) {

              $('form').find('.help-block').remove();
              $('form').find('.form-group').removeClass('has-error');

              $.each(error_response.responseJSON, function(key,value) {

                  $('#error_span').append('<li>'+value+'</li>').addClass('alert alert-danger');
                  $('#' + key ).parent().parent().append('<div class="col-sm-7 help-block">' + value + '</div>').closest('.form-group').removeClass('has-error').addClass('has-error');

              });

          }
      });
  });
</script>

<script>
        function previewImage(input){
          var file=$("input[type=file]").get(0).files[0];
          if(file)
          {
            var reader = new FileReader();
            reader.onload =function()
            {
              $('#image').attr("src",reader.result);
            }
            reader.readAsDataURL(file);
          }
        }

</script>

<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\globalskills.com.bd\resources\views/backend/pages/user_list.blade.php ENDPATH**/ ?>