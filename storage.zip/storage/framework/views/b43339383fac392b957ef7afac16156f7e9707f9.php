


<?php $__env->startSection('admin_dashboard_content'); ?>






<div class="container-fluid">
  <div class="db-breadcrumb">
    <h4 class="breadcrumb-title">Evolution List</h4>
    <ul class="db-breadcrumb-list">
      <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-home"></i>Home</a></li>
      <li>User</li>
    </ul>
  </div>

  <!-- Card -->

  <div class="row" id="basic-table">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Evolution Lists</h4>

        </div>


        <!-- Modal -->

        <div class="table table-responsive">
          <table id="evolution" class="table table-bordered">
            <thead>
              <tr>
                <th>No</th>
                <th>User Name</th>

                <th>Email</th>
                <th>Company Name</th>
                <th>Phone Number</th>
                <th>Course Name</th>
                <th>Course Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Reason for participation:</th>
                <th>Trainer’s competence Review</th>
                <th>Training presentation material Review</th>
                <th>Course material Review</th>
                <th>Usefulness of the training</th>
                <th>Experience about training and exam booking</th>
                <th>Overall satisfaction in this training </th>

              </tr>
            </thead>
            <tbody>

              <?php $__currentLoopData = $evolutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td><?php echo e($loop->index+1); ?></td>
                <td>
                    <?php echo e($row->users->name); ?>


                </td>
                <td><?php echo e($row->users->email); ?></td>
                <td><?php echo e($row->company_name); ?></td>
                <td><?php echo e($row->users->phone); ?></td>

                <td>
                    <?php echo e($row->course->course_title); ?>

                </td>
                <td>
                    <?php echo e($row->course->main_category->mcategory_title); ?>

                </td>
                <td>
                <?php echo e($row->start_date); ?>



                </td>

                <td><?php echo e($row->end_date); ?></td>
                <td>
                  <?php echo e($row->reason); ?>

                </td>
                <td><?php echo e($row->trainers_competence); ?></td>
                <td><?php echo e($row->presentation); ?></td>
                <td><?php echo e($row->material); ?></td>
                <td><?php echo e($row->usefullness); ?></td>
                <td><?php echo e($row->experience); ?></td>
                <td><?php echo e($row->satisfaction); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>

      </div>
    </div>
  </div>

</div>

<script>
  $(function(){
    'use strict';

    $('#evolution').DataTable({
      responsive: false,
      language: {
        searchPlaceholder: 'Search...',
        sSearch: '',
        lengthMenu: '_MENU_ ',
      }
    });


  });
</script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views/backend/pages/manage_evolution.blade.php ENDPATH**/ ?>