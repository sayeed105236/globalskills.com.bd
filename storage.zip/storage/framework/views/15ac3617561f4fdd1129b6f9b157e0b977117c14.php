


<?php $__env->startSection('content'); ?>
<div class="page-content bg-white">
<div class="page-banner ovbl-dark" style="background-image:url(<?php echo e(asset('images/banner/banner2.jpg')); ?>')}});">
    <div class="container">
        <div class="page-banner-entry">
          <br/>
          <br/>

 </div>
    </div>
</div>
<!-- Breadcrumb row -->
<div class="breadcrumb-row">
<div class="container">
<ul class="list-inline">
  <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
  <li>Our Experts</li>
</ul>
</div>
</div>


<div class="content-block">
<div class="section-area section-sp1">


   <!-- Left part start -->
   <div class="section-area content-inner service-info-bx">
             <div class="container">
       <div class="row">
         <div class="col-lg-3 col-md-4 col-sm-6 mt-4">
           <div class="service-bx">
             <div class="action-box">
               <img src="<?php echo e(asset('images/our-services/pic1.jpg')); ?>" alt="">
             </div>
             <div class="info-bx text-center">
               <div class="feature-box-sm radius bg-white">
                 <i class="fa fa-bank text-primary"></i>
               </div>
               <h4><a href="#">Best Industry Leaders</a></h4>
               <a href="#" class="btn radius-xl">View More</a>
             </div>
           </div>
         </div>
         <div class="col-lg-3 col-md-4 col-sm-6 mt-4">
           <div class="service-bx">
             <div class="action-box">
               <img src="<?php echo e(asset('images/our-services/pic2.jpg')); ?>" alt="">
             </div>
             <div class="info-bx text-center">
               <div class="feature-box-sm radius bg-white">
                 <i class="fa fa-book text-primary"></i>
               </div>
               <h4><a href="#">Learn Courses Online</a></h4>
               <a href="#" class="btn radius-xl">View More</a>
             </div>
           </div>
         </div>
         <div class="col-lg-3 col-md-4 col-sm-12 mt-4">
           <div class="service-bx m-b0">
             <div class="action-box">
               <img src="<?php echo e(asset('images/our-services/pic3.jpg')); ?>" alt="">
             </div>
             <div class="info-bx text-center">
               <div class="feature-box-sm radius bg-white">
                 <i class="fa fa-file-text-o text-primary"></i>
               </div>
               <h4><a href="#">Book Library & Store</a></h4>
               <a href="#" class="btn radius-xl">View More</a>
             </div>
           </div>
         </div>
         <div class="col-lg-3 col-md-4 col-sm-6 mt-4">
           <div class="service-bx">
             <div class="action-box">
               <img src="<?php echo e(asset('images/our-services/pic1.jpg')); ?>" alt="">
             </div>
             <div class="info-bx text-center">
               <div class="feature-box-sm radius bg-white">
                 <i class="fa fa-bank text-primary"></i>
               </div>
               <h4><a href="#">Best Industry Leaders</a></h4>
               <a href="#" class="btn radius-xl">View More</a>
             </div>
           </div>
         </div>
         <div class="col-lg-3 col-md-4 col-sm-6 mt-4">
           <div class="service-bx">
             <div class="action-box">
               <img src="<?php echo e(asset('images/our-services/pic2.jpg')); ?>" alt="">
             </div>
             <div class="info-bx text-center">
               <div class="feature-box-sm radius bg-white">
                 <i class="fa fa-book text-primary"></i>
               </div>
               <h4><a href="#">Learn Courses Online</a></h4>
               <a href="#" class="btn radius-xl">View More</a>
             </div>
           </div>
         </div>
         <div class="col-lg-3 col-md-4 col-sm-12 mt-4">
           <div class="service-bx m-b0">
             <div class="action-box">
               <img src="<?php echo e(asset('images/our-services/pic3.jpg')); ?>" alt="">
             </div>
             <div class="info-bx text-center">
               <div class="feature-box-sm radius bg-white">
                 <i class="fa fa-file-text-o text-primary"></i>
               </div>
               <h4><a href="#">Book Library & Store</a></h4>
               <a href="#" class="btn radius-xl">View More</a>
             </div>
           </div>
         </div>
         <div class="col-lg-3 col-md-4 col-sm-6 mt-4">
           <div class="service-bx">
             <div class="action-box">
               <img src="<?php echo e(asset('images/our-services/pic2.jpg')); ?>" alt="">
             </div>
             <div class="info-bx text-center">
               <div class="feature-box-sm radius bg-white">
                 <i class="fa fa-book text-primary"></i>
               </div>
               <h4><a href="#">Learn Courses Online</a></h4>
               <a href="#" class="btn radius-xl">View More</a>
             </div>
           </div>
         </div>
         <div class="col-lg-3 col-md-4 col-sm-12 mt-4">
           <div class="service-bx m-b0">
             <div class="action-box">
               <img src="<?php echo e(asset('images/our-services/pic3.jpg')); ?>" alt="">
             </div>
             <div class="info-bx text-center">
               <div class="feature-box-sm radius bg-white">
                 <i class="fa fa-file-text-o text-primary"></i>
               </div>
               <h4><a href="#">Book Library & Store</a></h4>
               <a href="#" class="btn radius-xl">View More</a>
             </div>
           </div>
         </div>
       </div>
     </div>
         </div>
         <!-- Our Services END -->






   <!-- Side bar END -->

</div>
</div>
</div>








</div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\globalskills.com.bd\resources\views/frontend/pages/our_experts.blade.php ENDPATH**/ ?>