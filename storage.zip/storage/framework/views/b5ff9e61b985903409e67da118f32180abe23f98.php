


<?php $__env->startSection('admin_dashboard_content'); ?>

<div class="container-fluid">
  <div class="db-breadcrumb">
    <h4 class="breadcrumb-title">Blogs</h4>
    <ul class="db-breadcrumb-list">
      <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-home"></i>Home</a></li>
      <li>Blogs</li>
    </ul>
  </div>
  <!-- Card -->

  <div class="row" id="basic-table">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Blogs</h4>
          <a href="#" class="btn btn-primary float-right" data-toggle="modal" data-target="#BlogsAddModal"><i class="fas fa-plus-circle"></i></a>
          <?php echo $__env->make('backend.modals.blogsaddmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <!-- Modal -->
        <div class="table table-responsive">
          <table class="table table-bordered" id="blog_list">
            <thead>
              <tr>
                <th>
                  No
                </th>
                <th>Blogs Title</th>
                <th>Short Description</th>

                <th>Blogs Images</th>




                <th>Created At</th>
                <th>Updated At</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>

                <td><span class="font-weight-bold"></span><?php echo e($loop->index+1); ?></td>
                <td><span class="font-weight-bold">

                    <?php echo e($row->blogs_title); ?>

                </span></td>
                <td>
                    <?php echo e($row->short_description); ?>


                </td>
                <td>
                  <div class="avatar-group">
                    <div
                      data-toggle="tooltip"
                      data-popup="tooltip-custom"
                      data-placement="top"
                      title=""
                      class="avatar pull-up my-0"
                      data-original-title=""
                    >
                      <img
                        src="<?php echo e(asset('storage/blogs/' .$row->blogs_image)); ?>"
                        alt="image"
                        height="50"
                        width="50"

                      />
                    </div>
                  </div>
                  </td>

                <td>
                    <?php echo e($row->created_at); ?>


                </td>

                <td> <?php echo e($row->updated_at); ?>


              </td>




                <td>
                  <a href="/admin/home/blogs/details/<?php echo e($row->id); ?>"><i class="fas fa-file-upload"></i></a>
                  <a href="#" data-toggle="modal" data-target="#BlogsEditModal<?php echo e($row->id); ?>"><i class="fas fa-edit"></i></a>



                  <a id="delete" href="/admin/home/deleteBlog/<?php echo e($row->id); ?>"><i class="fas fa-trash"></i></a>
                  <?php echo $__env->make('backend.modals.blogseditmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>
        </div>
        <div class="col-lg-12 m-b20">

            <?php echo e($blog->links('frontend.partials.pagination')); ?>


        </div>
      </div>
    </div>
  </div>

</div>
<script>
  $(function(){
    'use strict';

    $('#blog_list').DataTable({
      responsive: true,
      language: {
        searchPlaceholder: 'Search...',
        sSearch: '',
        lengthMenu: '_MENU_ ',
      }
    });


  });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views/backend/pages/blogs/manage.blade.php ENDPATH**/ ?>