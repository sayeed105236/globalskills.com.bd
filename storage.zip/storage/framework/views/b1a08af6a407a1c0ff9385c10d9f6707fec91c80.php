
<?php $__env->startSection('admin_dashboard_content'); ?>

<div class="container-fluid">
  <div class="db-breadcrumb">
    <h4 class="breadcrumb-title">Customer Contact</h4>
    <ul class="db-breadcrumb-list">
      <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-home"></i>Home</a></li>
      <li>Reviews</li>
    </ul>
  </div>


  <!-- Card -->
  <div class="row" id="basic-table">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Contacts</h4>
       <a href="#" class="btn btn-success" data-toggle="modal" data-target="#"><i class="fas fa-plus"></i></a>
        </div>

        <div class="table table-responsive">
          <table id="message_list" class="table table-bordered">
            <thead>
              <tr>
                <th>SL</th>
                <th>User Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Message</th>
                <th>Report Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
              <td><?php echo e($loop->index+1); ?></td>
                <td class="user_name">
                    <?php echo e($row->name); ?>

                </td>

                <td>
                    <?php echo e($row->email); ?>

                </td>
                <td>
                    <?php echo e($row->phone); ?>

                </td>
                <td>
                    <textarea name="" id="" cols="30" disabled rows="2"><?php echo e($row->message); ?></textarea>

                </td>
                <td><?php echo e($row->created_at); ?></td>
                <td>
                  <a id="delete" href="/admin/delete/<?php echo e($row->id); ?>"><i class="fas fa-trash"></i></a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

    <!-- Modal -->

</div>


<?php $__env->startPush('scripts'); ?>
<script>
      $(function(){
    'use strict';

    $('#message_list').DataTable({
      responsive: false,
      language: {
        searchPlaceholder: 'Search...',
        sSearch: '',
        lengthMenu: '_MENU_ ',
      }
    });
  })
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views/backend/pages/contact/index.blade.php ENDPATH**/ ?>