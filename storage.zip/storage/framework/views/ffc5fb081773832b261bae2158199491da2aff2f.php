<?php if($paginator->hasPages()): ?>
<div class="pagination-bx rounded-sm gray clearfix">
  <ul class="pagination">

    <?php if($paginator->onFirstPage()): ?>
    <li class="previous"><a><i class="ti-arrow-left"></i> Prev</a></li>



    <?php else: ?>
    <li class="previous"><a href="<?php echo e($paginator->previousPageUrl()); ?>"><i class="ti-arrow-left"></i> Prev</a></li>

    <?php endif; ?>

    <?php if(is_array($elements[0])): ?>
    <?php $__currentLoopData = $elements[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="active"><a href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if($paginator->hasMorePages()): ?>
    <li class="next"><a href="<?php echo e($paginator->nextPageUrl()); ?>">Next <i class="ti-arrow-right"></i></a></li>

    <?php endif; ?>



  </ul>
</div>


<?php endif; ?>
<?php /**PATH C:\xampp2\htdocs\globalskills.com.bd\resources\views/frontend/partials/pagination.blade.php ENDPATH**/ ?>