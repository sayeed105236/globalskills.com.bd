<div class="modal fade" id="SectionEditModal<?php echo e($section->id); ?>" tabindex="-1" role="dialog" aria-labelledby="SectionEditModal" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="SectionEditModal">Edit Section</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('secton-update')); ?>" method="POST">
          <?php echo csrf_field(); ?>
            <input type="hidden" name="section_id" value="<?php echo e($section->id); ?>">
            <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">
            <div class="form-group">
              <label for="order">Order No</label>
              <input type="number" class="form-control" value="<?php echo e($section->order); ?>" name="order" aria-describedby="order" placeholder="Section No">

            </div>

            <div class="form-group">
              <label for="section_name">Section Title</label>
              <input type="text" class="form-control" name="section_name" value="<?php echo e($section->section_name); ?>" aria-describedby="section_name" placeholder="Enter section name">
            </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
        </form>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views/backend/modals/section_editmodal.blade.php ENDPATH**/ ?>