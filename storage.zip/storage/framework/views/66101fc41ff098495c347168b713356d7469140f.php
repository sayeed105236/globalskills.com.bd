<div class="section-area section-sp2 popular-courses-bx">
          <div class="container">
    <div class="row">
      <div class="col-md-12 heading-bx left">
        <?php
        $classroom_courses = App\Models\ClassroomCourse::all();

         ?>


        <h2 class="title-head">Classroom <span>Courses</span></h2>



      </div>
    </div>
    <div class="row">

    <div class="courses-carousel owl-carousel owl-btn-1 col-12 p-lr0">
      <?php
      $classroom_courses = App\Models\ClassroomCourse::all();

       ?>
      <?php $__currentLoopData = $classroom_courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($row->status==1): ?>
      <div class="item" >
        <div class="cours-bx">
          <div class="action-box">
            <a href="<?php echo e(url('home/classroom/course_details/'.$row->id.'/'.$row->classroom_slug)); ?>"><img src="<?php echo e(asset("storage/Classroom courses/$row->classroom_course_image")); ?>" alt=""></a>
            <!--<form class="hidden" action="<?php echo e(route('add-carts')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="classroom_course_id" value="<?php echo e($row->id); ?>">

              <button  class="btn">Add to Cart</button>
            </form>-->
          </div>
          <div class="info-bx text-center">
            <h5><a href="<?php echo e(url('home/classroom/course_details/'.$row->id.'/'.$row->classroom_slug)); ?>"><?php echo e(Str::limit($row->classroom_course_title,18)); ?></a></h5>
            <span><?php echo e($row->course_category->mcategory_title); ?></span>
          </div>
          <div class="cours-more-info">
            <div class="review">
              <span>Review</span>
              <ul class="cours-star">
                <?php if(App\Models\CourseReview::where('classroomcourse_id',$row->id)->first()): ?>


                <?php
                   $courseReview=App\Models\CourseReview::where('classroomcourse_id',$row->id)->where('status','approve')->latest()->get();
                  $rating = App\Models\CourseReview::where('classroomcourse_id',$row->id)->where('status','approve')->avg('rating');
                  $avgRating = number_format($rating,1);
                ?>
                <?php for($i =1 ; $i <= 5 ; $i++): ?>
                <span style="color: red" class="fa fa-star<?php echo e(($i <= $avgRating) ? '' : '-empty'); ?>"></span>
              <?php endfor; ?>

              <?php else: ?>
              <span class="text-danger">No Review</span>
              <?php endif; ?>

              </ul>
            </div>
            <div class="price">
              <del><?php echo e($row->training_fee); ?>৳</del>
              <h5 style="color:#ca2128;"><?php echo e($row->exam_fee); ?>৳</h5>
            </div>
          </div>
        </div>
      </div>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    </div>

  </div>
</div>
<div class="text-center">
  <a href="<?php echo e(route('classroom-courses')); ?>" class="btn">View All</a>
</div>
<?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views/frontend/content/classroom.blade.php ENDPATH**/ ?>