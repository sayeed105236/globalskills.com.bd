<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/assets.css')); ?>">

<!-- TYPOGRAPHY ============================================= -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/typography.css')); ?>">

<!-- SHORTCODES ============================================= -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/shortcodes/shortcodes.css')); ?>">

<!-- STYLESHEETS ============================================= -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
<link class="skin" rel="stylesheet" type="text/css" href="<?php echo e(asset('css/color/color-1.css')); ?>">

<!-- REVOLUTION SLIDER CSS ============================================= -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/revolution/css/layers.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/revolution/css/settings.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('vendors/revolution/css/navigation.css')); ?>">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/lib/toastr/toastr.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/vanillajs-datepicker@1.1.4/dist/css/datepicker.min.css">
<link rel="stylesheet" href="<?php echo e(asset('common' )); ?>/modal-video.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="<?php echo e(asset('venobox')); ?>/venobox/venobox.css" type="text/css" media="screen" />
<?php /**PATH C:\xampp2\htdocs\globalskills.com.bd\resources\views/frontend/partials/styles.blade.php ENDPATH**/ ?>