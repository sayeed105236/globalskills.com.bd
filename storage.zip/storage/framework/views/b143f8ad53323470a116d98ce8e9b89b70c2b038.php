<!DOCTYPE html>
<html lang="en">


<head>

	<!-- META ============================================= -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="keywords" content="" />
	<meta name="author" content="" />
	<meta name="robots" content="" />

	<!-- DESCRIPTION -->
	<meta name="description" content="Global Skills Development Agency" />

	<!-- OG -->
	<meta property="og:title" content="Global Skills Development Agency" />
	<meta property="og:description" content="Global Skills Development Agency" />
	<meta property="og:image" content="" />
	<meta name="format-detection" content="telephone=no">

	<!-- FAVICONS ICON ============================================= -->
	<link rel="icon" href="<?php echo e(asset('images/favicon.ico')); ?>" type="image/x-icon" />
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/favicon.png')); ?>" />

	<!-- PAGE TITLE HERE ============================================= -->
	<title>Global Skills Development Agency</title>

	<!-- MOBILE SPECIFIC ============================================= -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!--[if lt IE 9]>
	<script src="<?php echo e(asset('js/html5shiv.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/respond.min.js')); ?>"></script>
	<![endif]-->

	<!-- All PLUGINS CSS ============================================= -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/assets.css')); ?>">

	<!-- TYPOGRAPHY ============================================= -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/typography.css')); ?>">

	<!-- SHORTCODES ============================================= -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/shortcodes/shortcodes.css')); ?>">

	<!-- STYLESHEETS ============================================= -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">
	<link class="skin" rel="stylesheet" type="text/css" href="<?php echo e(asset('css/color/color-1.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/lib/toastr/toastr.css">

</head>



<!-- Content -->
<div class="page-wraper">
	<div id="loading-icon-bx"></div>
	<div class="account-form">
		<div class="account-head" style="background-image:url(<?php echo e(asset('images/background/bg2.jpg')); ?>);">
			<a href="index.html"><img src="<?php echo e(asset('images/gsda logo.png')); ?>" alt=""></a>
		</div>
		<div class="account-form-inner">
			<div class="account-container">
				<div class="heading-bx left">
					<h2 class="title-head">Login to your <span>Account</span></h2>
					<p>Don't have an account? <a href="<?php echo e(route('register')); ?>">Create one here</a></p>
				</div>
        <form class="contact-bx" method="POST" action="<?php echo e(route('login')); ?>">
          <?php echo csrf_field(); ?>
          <div class="row placeani">
            <div class="col-lg-12">
              <div class="form-group">
                <div class="input-group">
                  <label for="email">Email</label>
                  <input id="email" type="email" required="" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>


                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="form-group">
                <div class="input-group">
                  <label for="password">Your Password</label>
                  <input id="password" type="password" class="form-control" name="password" required autocomplete="current-password">


                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                          <strong><?php echo e($message); ?></strong>
                      </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
            </div>
            <div class="col-lg-12">
              <div class="form-group form-forget">
                <div class="custom-control custom-checkbox">

                  <input class="custom-control-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                  <label class="custom-control-label" for="remember">Remember me</label>

                </div>
                  <?php if(Route::has('password.request')): ?>
                <a href="<?php echo e(route('password.request')); ?>" class="ml-auto">Forgot Password?</a>
                <?php endif; ?>
              </div>
            </div>
            <div class="col-lg-12 m-b30">
              <button name="submit" type="submit" value="Submit" class="btn button-md">Login</button>

            </div>
            <div class="col-lg-12">
              <h6>Login with Social media</h6>
              <div class="d-flex">
								<a class="btn flex-fill m-r5 facebook" href="<?php echo e(route('login.facebook')); ?>"><i class="fa fa-facebook"></i>Facebook</a>
								<a class="btn flex-fill m-l5 google-plus" href="<?php echo e(route('login.google')); ?>"><i class="fa fa-google-plus"></i>Google</a>
              </div>
            </div>
          </div>
        </form>
			</div>
		</div>
	</div>
</div>






<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/bootstrap/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/bootstrap-select/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/bootstrap-touchspin/jquery.bootstrap-touchspin.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/magnific-popup/magnific-popup.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/counter/waypoints-min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/counter/counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/imagesloaded/imagesloaded.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/masonry/masonry.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/masonry/filter.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/owl-carousel/owl.carousel.js')); ?>"></script>
<script src="<?php echo e(asset('js/functions.js')); ?>"></script>
<script src="<?php echo e(asset('js/contact.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/switcher/switcher.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('backend')); ?>/lib/toastr/toastr.min.js"></script>

<script>
  <?php if(Session::has('message')): ?>
	var type ="<?php echo e(Session::get('alert-type','info')); ?>"
	switch(type){
		case 'info':
			toastr.info(" <?php echo e(Session::get('message')); ?> ");
			break;
		case 'success':
			toastr.success(" <?php echo e(Session::get('message')); ?> ");
			break;
		case 'warning':
			toastr.warning(" <?php echo e(Session::get('message')); ?> ");
			break;
		case 'error':
			toastr.error(" <?php echo e(Session::get('message')); ?> ");
			break;
	}
<?php endif; ?>
</script>
</body>

</html>
<?php /**PATH C:\xampp2\htdocs\globalskills.com.bd\resources\views/auth/login.blade.php ENDPATH**/ ?>