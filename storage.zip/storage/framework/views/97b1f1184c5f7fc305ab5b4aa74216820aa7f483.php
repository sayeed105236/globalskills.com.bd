<h1>Hello</h1>
<p>I am <?php echo e($name); ?></p>
<?php echo e($data); ?>

<p>Email : <?php echo e($email); ?> </p>
<p>Phone : <?php echo e($phone); ?></p>
<?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views/email.blade.php ENDPATH**/ ?>