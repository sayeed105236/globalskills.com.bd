


<?php $__env->startSection('admin_dashboard_content'); ?>






<div class="container-fluid">
  <div class="db-breadcrumb">
    <h4 class="breadcrumb-title">Course Details</h4>
    <ul class="db-breadcrumb-list">
      <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-home"></i>Home</a></li>
      <li><?php echo e($course->course_title); ?> </li>
    </ul>
  </div>
  <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#CourseDetailsAddModal">Add Course Details</a>
  <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#CourseDetailsUpdateModal">View Course Details</a>

  </div>
  <br/>


  <br>

  <div class="container">


  <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#SectionAddModal">Add Section</a>
    </div>
    <br>
    <section id="accordion-hover">
      <div class="row">
        <div class="col-sm-12">
          <div class="card collapse-icon">

              <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="card-body">

              <div class="accordion" id="accordionExample<?php echo e($row->id); ?>" data-toggle-hover="true">
                <div class="collapse-default">





                  <div class="card">





                    <div
                      class="card-header"
                      id="heading<?php echo e($row->id); ?>"
                      data-toggle="collapse"
                      role="button"
                      data-target="#collapse<?php echo e($row->id); ?>"
                      aria-expanded="true"
                      aria-controls="collapse<?php echo e($row->id); ?>"
                    >
                      <span class="lead collapse-title collapse-hover-title"><?php echo e($row->section_name); ?></span>
                      <br>
                      <a href="#"  data-toggle="modal" data-target="#LessonAddModal"><i class="fas fa-file-upload"></i></a>
                      <a href="#"><i class="fas fa-edit"></i></a>
                      <a href="#"><i class="fas fa-trash"></i></a>

                    </div>











                    <div
                      id="collapse<?php echo e($row->id); ?>"
                      class="collapse show"
                      aria-labelledby="heading<?php echo e($row->id); ?>"
                      data-parent="#accordionExample<?php echo e($row->id); ?>"
                    >
                      <div class="card-body">
                        <div class="table-responsive">
                          <table class="table">
                            <thead>
                              <tr>
                                <th>Course Name</th>
                                <th>Section Name</th>

                                <th>Lesson ID</th>

                                <th>Video Type</th>
                                <th>Vimeo ID</th>
                                <th>Youtube Url</th>
                                <th>Lesson Title</th>
                                <th>Duration</th>
                                <th>Preview</th>
                                <th>Files</th>

                              </tr>
                            </thead>
                            <tbody>




                            <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                              $lessons = App\Models\Lesson::where('course_id', $lessons)->get();


                            ?>


                              <tr>
                                <td>
                                    <?php echo e($lesson->course->course_title); ?>

                                </td>
                                <td>

                                    <?php echo e($lesson->section->section_name); ?>

                                </td>
                                <td>

                                  <?php echo e($lesson->id); ?>

                                </td>
                                <td>
                                  <?php echo e($lesson->video_type); ?>


                                </td>
                                <td>
                                  <?php echo e($lesson->vimeo_id); ?>

                                </td>
                                <td><?php echo e($lesson->youtube_url); ?></td>
                                <td>

                                  <?php echo e($lesson->lesson_title); ?>

                                </td>
                                <td>


                                </td>
                                <td>
                                  <?php echo e($lesson->preview); ?>

                                </td>
                                <td>


                                  <?php echo e($lesson->files); ?>

                                </td>






                              </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>










                </div>
              </div>
            </div>


          </div>
        </div>
      </div>
    </section>









   <!-- Course Detailks add modal start-->
  <?php echo $__env->make('backend.modals.course_details_addmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Course Detailks add modal End-->


  <!--  Add Section Modal start-->

  <?php echo $__env->make('backend.modals.section_addmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <?php echo $__env->make('backend.modals.section_editmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <?php echo $__env->make('backend.modals.lesson_addmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('backend.modals.course_details_updatemodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--  Add Section Modal End-->

  <!-- Card -->









<script src="<?php echo e(asset('admin/js/components-collapse.js')); ?>"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views//backend/pages/courses/course_details.blade.php ENDPATH**/ ?>