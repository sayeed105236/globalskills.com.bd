


<?php $__env->startSection('content'); ?>





<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
  .img i {
  top: 15%;
  left: 50%;
  position: absolute;
  transform: translate(-50%, -50%);
}
  .img:hover {
  opacity: 1;
}
.fa-youtube:hover {
  color:red;
}
.fa-youtube {
  color:#CA2128;
}
.fa-play-circle {
  color:red;
}
.icn{
  margin-left:-7%;
  color:green;
}
</style>

<!-- Content -->

<div class="page-content bg-white">
    <!-- inner page banner -->
    <div class="page-banner ovbl-dark" style="background-image:url(<?php echo e(asset('images/banner/banner2.jpg')); ?>);">
        <div class="container">
            <div class="page-banner-entry">
              <br/>
              <br/>

     </div>
        </div>
    </div>
<!-- Breadcrumb row -->
<div class="breadcrumb-row">
  <div class="container">
    <ul class="list-inline">
      <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li>Courses Details</li>
    </ul>
  </div>
</div>
<!-- Breadcrumb row END -->
    <!-- inner page banner END -->
    <?php
    $courses = App\Models\Course::all();
    ?>


    <?php
    $course_categories= App\Models\CourseCategory::all();
    $main_categories= App\Models\MainCategory::all();
     ?>

<div class="content-block">
        <!-- About Us -->
  <div class="section-area section-sp1">
            <div class="container">
       <div class="row d-flex flex-row-reverse">
        <div class="col-lg-3 col-md-4 col-sm-12 m-b30">
          <div class="course-detail-bx">


        <?php if($course->video_type==0): ?>

        <div class="preview-video-box">

              <a class="venobox" data-autoplay="true" data-vbtype="video" href="<?php echo e($course->preview_id); ?>" data-gall="myGallery">
                <img src="<?php echo e(asset("storage/courses/$course->course_image")); ?>" alt="" class="img-fluid">
                <div class="img">
                  <i class="fab fa-youtube fa-4x"></i>
                </div>
              </a>
              <?php if(count($course->sections) > 0): ?>
              <?php $__currentLoopData = $course->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if(count($section->lessons) > 0): ?>
              <?php $__currentLoopData = $section->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($lesson->preview==1): ?>
              <a class="venobox" data-autoplay="true" data-vbtype="video" href="<?php echo e($lesson->youtube_url); ?>" data-gall="myGallery"></a>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>




      </div>
          <?php else: ?>
          <div class="preview-video-box">
            <a class="video-play" data-video-id="<?php echo e($course->preview_id); ?>" data-channel="vimeo">

                <img src="<?php echo e(asset("storage/courses/$course->course_image")); ?>" alt="" class="img-fluid">
                <div class="img">
                  <i class="fab fa-youtube fa-4x"></i>
                </div>

            </a>
        </div>
        <?php endif; ?>



          

            <?php if($enrolled): ?>
              <div class="course-price">
              <a href="/home/course_details/view/<?php echo e($course->id); ?>/<?php echo e($course->elearning_slug); ?>" class="btn">Already Enrolled</a>
            </div>
            <?php else: ?>

            <div class="course-price">
              <del><?php echo e($course->regular_price); ?>৳</del>
              <h4 class="price"><?php echo e($course->sale_price); ?>৳</h4>
            </div>
            <div class="course-buy-now text-center">



            </div>
            <br>
              <div class="course-buy-now text-center">

                <form class="hidden" action="<?php echo e(route('buy-now')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">

                  <button  class="btn">Buy Now</button>
                </form>



                  </div>
            <br>
            <div class="course-buy-now text-center">
            <form class="hidden" action="<?php echo e(route('add-carts')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">

              <button  class="btn">Add to Cart</button>
            </form>
          </div>
          <?php endif; ?>
            <div class="teacher-bx">
              <div class="teacher-info">
              <!--  <div class="teacher-thumb">
                  <img src="<?php echo e(asset('images/testimonials/pic1.jpg')); ?>" alt=""/>
                </div>-->
                <!--<div class="teacher-name">
                  <h5>Hinata Hyuga</h5>
                  <span>Science Teacher</span>
                </div>-->
              </div>
            </div>
            <div class="cours-more-info">
              <div class="review">
                <span>Review</span>
                <ul class="cours-star">
                 <?php for($i =1 ; $i <= 5 ; $i++): ?>
                             <span style="color: red" class="fa fa-star<?php echo e(($i <= $avgRating) ? '' : '-empty'); ?>"></span>
                           <?php endfor; ?>
                           <span>(<?php echo e(count($courseReview)); ?>)</span>
                           <h4>5/<?php echo e($avgRating); ?></h4>

                </ul>

              </div>
              <div class="price categories">
                <span>Categories</span>
                <h5 class="text-primary"><?php echo e($course->course_category->mcategory_title); ?></h5>
              </div>
            </div>
            <div class="course-info-list scroll-page">
              <ul class="navbar">
                <li><a class="nav-link" href="#overview"><i class="ti-zip"></i>Overview</a></li>
                <li><a class="nav-link" href="#curriculum"><i class="ti-bookmark-alt"></i>Curriculum</a></li>

                 <li><a class="nav-link" href="#instructor"><i class="ti-user"></i>Instructor</a></li>
                <li><a class="nav-link" href="#reviews"><i class="ti-comments"></i>Reviews</a></li>
              </ul>
            </div>
          </div>
        </div>

        <div class="col-lg-9 col-md-8 col-sm-12">
          <div class="courses-post">
            <div class="ttr-post-media media-effect">
              <a href="#"><img src="<?php echo e(asset('storage/courses/banners/'.$course->course_details->banner_image)); ?>"   alt="image"
                height="600"
                width="1000"></a>
            </div>
            <div class="ttr-post-info">
              <div class="ttr-post-title ">
                <h2 class="post-title"><?php echo e($course->course_title); ?></h2>
              </div>
              <div class="ttr-post-text">
                <?php echo $course->course_details->short_description; ?>

              </div>
            </div>
          </div>
          <div class="courese-overview" id="overview">
            <h4>Overview</h4>
            <div class="row">
              <div class="col-md-12 col-lg-4">
                <ul class="course-features">
                <!--  <li><i class="ti-book"></i> <span class="label">Lectures</span> <span class="value">8</span></li>-->
                  <li><i class="ti-help-alt"></i> <span class="label">Quizzes</span> <span class="value"><?php echo e($course->course_details->quiz); ?></span></li>
                <!--  <li><i class="ti-time"></i> <span class="label">Duration</span> <span class="value">60 hours</span></li>-->
                  <li><i class="ti-stats-up"></i> <span class="label">Skill level</span> <span class="value"><?php echo e($course->course_details->skill); ?></span></li>
                  <li><i class="ti-smallcap"></i> <span class="label">Language</span> <span class="value"><?php echo e($course->course_details->language); ?></span></li>
                <!--  <li><i class="ti-user"></i> <span class="label">Students</span> <span class="value">32</span></li>-->
                <!--  <li><i class="ti-check-box"></i> <span class="label">Assessments</span> <span class="value">Yes</span></li>-->
                 <li><i class="ti-time"></i> <span class="label">Duration</span> <span class="value">
                   <strong>
                    <?php
                    $total_duration = $data;
                    $H = floor($total_duration / 3600);
                    $i = ($total_duration / 60) % 60;
                    $s = $total_duration % 60;
                  if($H==NULL)
                  {
                  echo sprintf("%02d:%02d H", $i, $s);
                  }
                  else
                  {
                  echo sprintf("%02d:%02d:%02d H", $H, $i, $s);
                  }
                  ?>
                 </strong>
                  </span></li>
              </ul>
              </div>
              <div class="col-md-12 col-lg-8">
                <h5 class="m-b5">Course Description</h5>
                <?php echo $course->course_details->course_description; ?>

                  <div class="ttr-divider bg-gray"><i class="icon-dot c-square"></i></div>
                <h5 class="m-b5">Certification</h5>
                <p><?php echo e($course->course_details->certification); ?></p>
                  <div class="ttr-divider bg-gray"><i class="icon-dot c-square"></i></div>
                <h5 class="m-b5">Learning Outcomes</h5>
                <ul class="list-checked primary">
                  <?php echo $course->course_details->learning_outcomes; ?>


                </ul>
              </div>
            </div>
          </div>
          <div class="m-b30" id="curriculum">
            <h4>Curriculum</h4>

              <section id="accordion-hover">
                <div class="row">
                  <div class="col-sm-12">
                    <div class="card collapse-icon">

                      <div class="card-body">
                        <?php if(count($course->sections) > 0): ?>
                        <?php $__currentLoopData = $course->sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="accordion" id="accordionExample<?php echo e($section->id); ?>" data-toggle-hover="true">
                          <div class="collapse-default">

                            <div class="card">
                              <div
                                class="card-header"
                                id="heading<?php echo e($section->id); ?>"
                                data-toggle="collapse"
                                role="button"
                                data-target="#collapse<?php echo e($section->id); ?>"
                                aria-expanded="true"
                                aria-controls="collapse<?php echo e($section->id); ?>"
                              >
                                <h6 class="curriculum-list" style="color:#ca2128; text-transform:uppercase;" ><?php echo e($section->section_name); ?>

                                    <p class="pull-right"><i class="ti-time"></i>
                                  <span class="value">
                                   <?php
                                      $section_sum=App\Models\Lesson::where('section_id',$section->id)->sum('duration');
                                      $total_ = $section_sum;
                                      $Hours = floor($total_ / 3600);
                                      $Minuites = ($total_ / 60) % 60;
                                      $Seconds = $total_ % 60;
                                      echo sprintf("%02d:%02d:%02d Hours", $Hours, $Minuites, $Seconds);
                                   ?>
                                  </span>
                                </p>

                                </h6>
                              </div>

                              <div
                                id="collapse<?php echo e($section->id); ?>"
                                class="collapse show"
                                aria-labelledby="heading<?php echo e($section->id); ?>"
                                data-parent="#accordionExample<?php echo e($section->id); ?>"
                              >
                                <div class="card-body">
                                  <ul>
                                    <?php if(count($section->lessons) > 0): ?>
                                    <?php $__currentLoopData = $section->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($lesson->youtube_url): ?>
                                    <?php
                                    $video_url=$lesson->youtube_url;
                                     $api_key='AIzaSyDthwUfyzKUC2Nd_JEvPkLJjG-_ufy_w-E';
                                     preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $video_url, $match);
                                        $video_url = $match[1];
                                        $api_url='https://www.googleapis.com/youtube/v3/videos?part=snippet%2CcontentDetails%2Cstatistics&id='.$video_url.'&key='.$api_key;
                                        $data=json_decode(file_get_contents($api_url));
                                        $time=$data->items[0]->contentDetails->duration;
                                    ?>
                                    <?php endif; ?>
                                      <div class="curriculum-list-box">
                                        <div class="row">

                                      <div class="col-sm-8">


                                         <strong><i class="fas fa-play-circle"></i> <?php echo e($lesson->lesson_title); ?></strong>

                                        </div>
                                        <div class="col-sm-2">

                                          <?php if($lesson->youtube_url): ?>
                                          <i class="far fa-clock"></i>
                                          <?php
                                          $timeFormat = new DateTime('1970-01-01');
                                         $timeFormat->add(new DateInterval($time));
                                         if (strlen($time)>8)
                                         {
                                             echo $timeFormat->format('H:i:s');
                                     }   else {
                                         echo $timeFormat->format('H:i:s');
                                     }
                                     ?>
                                     <?php endif; ?>
                                        </div>
                                        <div class="col-sm-2">
                                          <?php if($lesson->preview==1): ?>
                                          <?php if($lesson->video_type=="Youtube"): ?>

                                          <a class="venobox" data-autoplay="true" data-vbtype="video" href="<?php echo e($lesson->youtube_url); ?>" data-gall="Gallery23">
                                            <strong><i  class="fas fa-play-circle fa-2x icn pull-right" title="Play"></i></strong>
                                            </a>
                                           <?php else: ?>
                                           <a class="video-play1" data-video-id="<?php echo e($lesson->vimeo_id); ?>" data-channel="vimeo">
                                            <strong><i class="fas fa-play-circle fa-2x icn pull-right"  title="Play"></i></strong>
                                          </a>
                                            <?php endif; ?>
                                            <?php else: ?>

                                          <i class="fas fa-lock pull-right" title="Lock"></i>
                                          <?php endif; ?>
                                        </div>
                                    <div class="col">


                                      <span><strong></strong></span>
                                    </div>
                                        </div>
                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      <?php endif; ?>



                                  </ul>


                                </div>
                              </div>
                            </div>


                          </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                      </div>
                    </div>
                  </div>
                </div>
              </section>


          </div>
          <div class="" id="instructor">
          <h4>Instructor</h4>

          <?php $__currentLoopData = $trainer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="instructor-bx">
            <div class="instructor-author">
              <img src="<?php echo e(asset($item->image)); ?>" alt="">
            </div>
            <div class="instructor-info">
              <h6><?php echo e($item->name); ?></h6>
              <span><?php echo e($item->designation); ?></span>
              <ul class="list-inline m-tb10">
                <li><a href="<?php echo e($item->facebook_profile); ?>" class="btn sharp-sm facebook"><i class="fab fa-facebook"></i></a></li>
                <li><a href="<?php echo e($item->linkdin_profile); ?>" class="btn sharp-sm linkedin"><i class="fab fa-linkedin"></i></a></li>
              </ul>
              <p class="m-b0"><?php echo $item->biography; ?></p>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>




          <div class="" id="reviews">
            <h4>Reviews</h4>

            <div class="review-bx">
              <div class="product-add-review">
                <h4 class="title">Write your own review</h4>
                <div class="review-table">
                  <div class="table-responsive">
                    <form role="form" class="cnt-form" action="<?php echo e(route('store.review')); ?>" method="post">
                    <table class="table" >
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">
                      <thead>
                        <tr>
                         <th class="cell-label">&nbsp;</th>
                         <th><i class="fa fa-star" style="color: red"></i></th>
                         <th><i class="fa fa-star" style="color: red"></i>
                           <i class="fa fa-star"  style="color: red"></i></th>
                         <th><i class="fa fa-star" style="color: red"></i>
                           <i class="fa fa-star" style="color: red"></i>
                           <i class="fa fa-star" style="color: red"></i></th>
                         <th><i class="fa fa-star" style="color: red"></i>
                           <i class="fa fa-star" style="color: red"></i>
                           <i class="fa fa-star" style="color: red"></i>
                           <i class="fa fa-star" style="color: red"></i></th>
                         <th><i class="fa fa-star" style="color: red"></i>
                           <i class="fa fa-star" style="color: red"></i>
                           <i class="fa fa-star" style="color: red"></i>
                           <i class="fa fa-star" style="color: red"></i>
                           <i class="fa fa-star" style="color: red"></i></th>
                       </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td class="cell-label">Rating</td>
                          <td><input type="radio" name="rating" class="radio" value="1"></td>
                          <td><input type="radio" name="rating" class="radio" value="2"></td>
                          <td><input type="radio" name="rating" class="radio" value="3"></td>
                          <td><input type="radio" name="rating" class="radio" value="4"></td>
                          <td><input type="radio" name="rating" class="radio" value="5"></td>
                        </tr>
                        <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                      </tbody>
                    </table><!-- /.table .table-bordered -->
                  </div><!-- /.table-responsive -->
                </div><!-- /.review-table -->

                <div class="review-form">
                  <div class="form-container">


                      <div class="row">

                        <div class="col-md-12">
                          <div class="form-group">
                            <label for="exampleInputReview">Review <span class="astk">*</span></label>
                            <textarea class="form-control txt txt-review" id="exampleInputReview" name="comment" rows="4" placeholder=""></textarea>
                            <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div><!-- /.form-group -->
                        </div>
                      </div><!-- /.row -->

                      <div class="action text-right">
                        <button class="btn btn-primary btn-upper">SUBMIT REVIEW</button>
                      </div><!-- /.action -->

                    </form><!-- /.cnt-form -->
                    <?php $__currentLoopData = $courseReview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <div class="product-reviews">
											<h5 class="title"><?php echo e($review->user->name); ?></h5>

                      <div class="reviews">
												<div class="review">
													<div class="review-title">
                              <span class="summary">
                            <?php for($i =1 ; $i <= 5 ; $i++): ?>
                             <span style="color: red" class="fa fa-star<?php echo e(($i <= $review->rating) ? '' : '-empty'); ?>"></span>
                           <?php endfor; ?>
                              </span>
                           <span class="date"><i class="fa fa-calendar"></i><span> <?php echo e($review->created_at->diffForHumans()); ?></span></span></div>
													<div class="text">"<?php echo e($review->comment); ?>" </div>
                        </div>
											</div><!-- /.reviews -->
										</div><!-- /.product-reviews -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div><!-- /.form-container -->
                </div><!-- /.review-form -->

              </div><!-- /.product-add-review -->


            </div>

          </div>

        </div>

      </div>
    </div>
        </div>
    </div>






<!-- contact area END -->

</div>
<!-- Content END-->

<script>$(document.frmTransaction.submit());</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\globalskills.com.bd\resources\views//backend/pages/courses/course_details_index.blade.php ENDPATH**/ ?>