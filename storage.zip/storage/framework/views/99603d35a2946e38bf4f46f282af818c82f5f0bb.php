
<?php $__env->startSection('admin_dashboard_content'); ?>
<?php $__env->startSection('active'); ?>
   trainers
<?php $__env->stopSection(); ?>

<div class="container-fluid">
  <div class="db-breadcrumb">
    <h4 class="breadcrumb-title">Trainer List</h4>
    <ul class="db-breadcrumb-list">
      <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-home"></i>Home</a></li>
      <li>Trainer</li>
    </ul>
  </div>


  <!-- Card -->
  <div class="row" id="basic-table">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
            <h4 class="card-title">Trainer</h4>
            <a href="#" class="btn btn-primary float-right" data-toggle="modal" data-target="#TrainerAdd"><i class="fas fa-plus-circle"></i></a>
            <?php echo $__env->make('backend.modals.traineraddmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>



        <div class="table table-responsive">
          <table id="user_list" class="table table-bordered">
            <thead>
              <tr>
                <th class="wd-10">Id</th>
                <th>Name</th>
                <th>Course</th>
                <th class="wd-10">Designation</th>
                <th>Fb Link</th>
                <th>Lindin Link</th>
                <th>Biography</th>
                <th>Image</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $trainer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td><?php echo e($row->id); ?></td>
                <td class="user_name">
                    <?php echo e($row->name); ?>


                </td>
                <td>
                  <?php echo e($row->course->course_title); ?>

                </td>

                <td>
                    <?php echo e($row->designation); ?>

                </td>
                <td>
                    <?php echo e($row->facebook_profile); ?>

                </td>
                <td>
                    <?php echo e($row->linkdin_profile); ?>

                </td>
                <td>
                    <textarea name="" id="" cols="30" disabled rows="2"><?php echo e($row->biography); ?></textarea>
                </td>
                <td>
                    <div class="avatar-group">
                      <div
                        data-toggle="tooltip"
                        data-popup="tooltip-custom"
                        data-placement="top"
                        title=""
                        class="avatar pull-up my-0"
                        data-original-title=""
                      >
                        <img
                          src="<?php echo e(asset($row->image)); ?>"
                          alt="image"
                          height="50"
                          width="50"

                        />
                      </div>


                    </div>
                </td>

                <td>
                    <a href="#" data-toggle="modal" data-target="#TrainerEdit<?php echo e($row->id); ?>"><i class="fas fa-edit"></i></a>

                  <a  href="/admin/trainer-delete/<?php echo e($row->id); ?>" id="delete"><i class="fas fa-trash"></i></a>
                      <?php echo $__env->make('backend.modals.trainereditmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </td>




              </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>

      </div>
    </div>
  </div>

    <!-- Modal -->

</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views/backend/pages/trainer/create.blade.php ENDPATH**/ ?>