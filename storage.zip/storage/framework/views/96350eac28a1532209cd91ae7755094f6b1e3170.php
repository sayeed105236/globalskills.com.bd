<div class="section-area content-inner service-info-bx">
          <div class="container">
    <div class="row">
      <?php
      $categories = App\Models\MainCategory::all();

       ?>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


      <div class="col-lg-4 col-md-4 col-sm-6">
        <div class="service-bx">
          <div class="action-box">
            <img src="<?php echo e(asset("storage/category/$row->image")); ?>" alt="">
          </div>
          <div class="info-bx text-center">
            <div class="feature-box-sm radius bg-white">
              <i class="fa fa-bank text-primary"></i>
            </div>
            <h4 style="color:#ca2128; text-transform:uppercase;"><?php echo e($row->mcategory_title); ?></h4>

          </div>
        </div>
      </div>



      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
  </div>
      </div>
      <!-- Our Services END -->
<?php /**PATH C:\xampp2\htdocs\globalskills.com.bd\resources\views/frontend/content/inner_service.blade.php ENDPATH**/ ?>