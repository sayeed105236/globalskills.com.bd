<style>
    .search-item-design{
        padding-top: 10px;
    }
   .design-li{
        list-style: none;
        padding: 0 20px;
    }
    .design-li:hover{
        background:#DA9F0D;
        cursor: pointer;
    }
    .design-li a:hover{
       color:white;
    }
</style>

<ul class="search-item-design">
    <?php $__empty_1 = true; $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <a href="<?php echo e(url('home/course_details/'.$item->id.'/'.$item->elearning_slug)); ?>">
        <li class="design-li">
            <img src="<?php echo e(asset("storage/courses/$item->course_image")); ?>" alt="" height="40px;" width="40px;">
            <strong style="color: white"><?php echo e($item->course_title); ?></strong> <hr>
        </li>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div style="color:white; padding:0 20px;">No E-Learning Course Found</div>
    <?php endif; ?>
</ul>

<ul class="search-item-design">
    <?php $__empty_1 = true; $__currentLoopData = $classroom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <a href="<?php echo e(url('home/classroom/course_details/'.$item->id.'/'.$item->classroom_slug)); ?>">
        <li class="design-li">
            <img src="<?php echo e(asset("storage/Classroom courses/$item->classroom_course_image")); ?>" alt="" height="40px;" width="40px;">
            <strong style="color: white"><?php echo e($item->classroom_course_title); ?></strong> <hr>
        </li>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div style="color:white; padding:0 20px;">No Classroom Course Found</div>
    <?php endif; ?>
</ul>
<?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views/search-course.blade.php ENDPATH**/ ?>