<div class="modal fade" id="TrainerEdit<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="TrainerEditModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="TrainerEditModal<?php echo e($row->id); ?>">Edit Trainer</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('update-trainer')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($row->id); ?>">
            <input type="hidden" name="old_image" value="<?php echo e($row->image); ?>">
            <input type="hidden" name="old_image1" value="<?php echo e($row->signature); ?>">

              <div class="form-group">
                <label for="classroom_course_title" >Name</label>
                <input data-validation="required" value="<?php echo e($row->name); ?>" type="text" class="form-control" name="name" aria-describedby="name" placeholder="Enter Name">

              </div>
              <div class="form-group">
                <label for="custom select">Select Course</label>
                <select class="form-control" name="course_id">
                  <option label="Choose Course"></option>
                  <?php foreach ($course as $item): ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->course_title); ?></option>

                  <?php endforeach; ?>




                </select>
              </div>
              <div class="form-group">
                <label class="col-form-label">Designation</label>
                <div>
                  <input  class="form-control" value="<?php echo e($row->designation); ?>" name="designation"> </input>
                </div>
              </div>
              <div class="form-group">
                <label class="col-form-label">Fb link</label>
                <div>
                  <input  class="form-control" name="facebook_profile" value="<?php echo e($row->facebook_profile); ?>"> </input>
                </div>
              </div>
              <div class="form-group">
                <label class="col-form-label">Linkdin link</label>
                <div>
                  <input  class="form-control" name="linkdin_profile" value="<?php echo e($row->linkdin_profile); ?>"> </input>
                </div>
              </div>
              <div class="form-group">
                <label class="col-form-label">Biography</label>
                <div>
                  <textarea class="form-control" id="bio" name="biography" value="<?php echo e($row->biography); ?>" > </textarea>
                </div>
              </div>
              <div class="form-group">
                  <label for="exampleFormControlFile1">Image</label>
                    <input  type="file" name="image" class="form-control-file" id="image" >
                  </div>
                   <div class="form-group">
                    <label class="form-control-label">Signature: <span class="tx-danger">*</span></label>
                    <input class="form-control" type="file" name="signature" >
                  </div>

                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
          </form>
      </div>
    </div>
  </div>
  <?php $__env->startPush('scripts'); ?>
  <script>
    $(document).ready(function() {
      $('#bio').summernote();
    });
    </script>

  <?php $__env->stopPush(); ?>
<?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views/backend/modals/trainereditmodal.blade.php ENDPATH**/ ?>