
<?php $__env->startSection('admin_dashboard_content'); ?>
<?php $__env->startSection('active'); ?>
   trainers
<?php $__env->stopSection(); ?>

<div class="container-fluid">
  <div class="db-breadcrumb">
    <h4 class="breadcrumb-title">FAQ</h4>
    <ul class="db-breadcrumb-list">
      <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-home"></i>Home</a></li>
      <li>FAQ</li>
    </ul>
  </div>


  <!-- Card -->
  <div class="row" id="basic-table">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
            <h4 class="card-title">FAQ</h4>
            <a href="#" class="btn btn-primary float-right" data-toggle="modal" data-target="#FaqAdd"><i class="fas fa-plus-circle"></i></a>
             <?php echo $__env->make('backend.modals.faqaddmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        <div class="table table-responsive">
          <table id="user_list" class="table table-bordered">
            <thead>
              <tr>
                <th class="wd-10">SL</th>
                <th>Subject</th>
                <th>Description</th>
                <th class="wd-10">Video Url</th>
                <th>Image</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
               <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td><?php echo e($loop->index+1); ?></td>
                <td class="user_name">
                    <?php echo e($row->subject); ?>

                </td>
                <td>
                    <textarea name="" id="" cols="30" disabled rows="2"><?php echo $row->description; ?></textarea>
                </td>

                <td>
                    <?php echo e($row->video_url); ?>

                </td>
                <td>
                    <img src="<?php echo e(asset( $row->image)); ?>" alt="">
                </td>
                <td>
                    <a href="#" data-toggle="modal" data-target="#FaqEdit<?php echo e($row->id); ?>"><i class="fas fa-edit"></i></a>

                  <a  href="/admin/delete-faq/<?php echo e($row->id); ?>" id="delete"><i class="fas fa-trash"></i></a>
                      

                </td>




              </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>

      </div>
    </div>
  </div>

    <!-- Modal -->

</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views/backend/pages/faq/create.blade.php ENDPATH**/ ?>