


<?php $__env->startSection('admin_dashboard_content'); ?>

<div class="db-breadcrumb">
  <h4 class="breadcrumb-title">Course Details</h4>
  <ul class="db-breadcrumb-list">
    <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-home"></i>Home</a></li>
    <li><?php echo e($classroom_course->classroom_course_title); ?> </li>
  </ul>
</div>


<div class="row match-height">
  <!-- Base Nav starts -->
  <div class="col-md-12 col-sm-12">
    <div class="card">
      <div class="card-header">
        <h4 class="card-title"><?php echo e($classroom_course->classroom_course_title); ?></h4>
      </div>
      <div class="card-body">

        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link active" style="color:red;" href="#">Course Info</a>
          </li>


          <li class="nav-item">
            <a class="nav-link" href="#">Media</a>
          </li>
          <a class="btn btn-primary" href=" /admin/home/classroom/courses/course_details/<?php echo e($classroom_course->id); ?>" >Back</a>


        </ul>
      </div>
    </div>
  </div>
  <!-- Base Nav ends -->


</div>
<br>
<div class="card">
    <div class="card-header">

<a href="#"  data-toggle="modal" data-target="#ClassroomCourseDetailsEditModal"><i class="fas fa-edit"></i></a>
<?php echo $__env->make('backend.modals.classroom_course_detailseditmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="table-responsive">
  <table class="table">
    <thead>
      <tr>
        <th>
          Course Id
        </th>
        <th>Course Title</th>

        <th>Banner Images</th>
        <th>Short Description</th>
        <th>Course Description</th>
        <th>Learning Outcomes</th>
        <th>Certification</th>
        <th>Instructor ID</th>
        <th>Pass Marks</th>
        <th>Out of Marks</th>
        <th>Percentage</th>
        <th>No of Questions</th>
        <th>Exam Type</th>
        <th>Duration</th>
        <th>Exam Format</th>

      </tr>
    </thead>
    <tbody>


      <tr>

        <td>
            <?php echo e($classroom_course->id); ?>

        </td>
        <td>
            <?php echo e($classroom_course->classroom_course_title); ?>


        </td>
        <td>
          <div class="avatar-group">
            <div
              data-toggle="tooltip"
              data-popup="tooltip-custom"
              data-placement="top"
              title=""
              class="avatar pull-up my-0"
              data-original-title=""
            >
              <img
                src="<?php echo e(asset("storage/Classroomk Courses/banners/$classroom_course_details->classroom_banner_image")); ?>"
                alt="image"
                height="50"
                width="50"

              />
            </div>


          </div>

        </td>

        <td>

            <?php echo e($classroom_course_details->classroom_short_description); ?>


        </td>
        <td>
            <?php echo e($classroom_course_details->classroom_course_description); ?>


        </td>
        <td>
            <?php echo e($classroom_course_details->classroom_learning_outcomes); ?>



        </td>
        <td>
            <?php echo e($classroom_course_details->classroom_certification); ?>


        </td>

        <td>
            <?php echo e($classroom_course_details->classroom_instructor_id); ?>

        </td>
        <td>
              <?php echo e($classroom_course_details->pass_mark); ?>

          </td>
        <td>
            <?php echo e($classroom_course_details->out_of); ?>


        </td>
        <td>
          <?php echo e($classroom_course_details->pass_mark/$classroom_course_details->out_of*100); ?>%


        </td>
        <td>
            <?php echo e($classroom_course_details->no_of_questions); ?>

        </td>
        <td>

            <?php echo e($classroom_course_details->exam_type); ?>

        </td>
        <td>
            <?php echo e($classroom_course_details->duration); ?>

        </td>
        <td>
            <?php echo e($classroom_course_details->book); ?>

        </td>

      </tr>





    </tbody>
  </table>
</div>
</div>


















<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views//backend/pages/classroom_courses/classroom_course_info.blade.php ENDPATH**/ ?>