


<?php $__env->startSection('admin_dashboard_content'); ?>






<div class="container-fluid">
  <div class="db-breadcrumb">
    <h4 class="breadcrumb-title">Experts</h4>
    <ul class="db-breadcrumb-list">
      <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-home"></i>Home</a></li>
      <li>Manage Expert Lists</li>
    </ul>
  </div>
  <!-- Card -->

  <div class="row" id="basic-table">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Manage Expert Lists</h4>
          <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#ExpertAddModal"><i class="fas fa-plus-circle"></i></a>
          <?php echo $__env->make('backend.modals.expertaddmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php if(Session::has('exper_added')): ?>
        <div class="alert alert-success" role="alert">

          <div class="alert-body">
            <?php echo e(Session::get('exper_added')); ?>

          </div>
        </div>

        <?php elseif(Session::has('exper_deleted')): ?>
        <div class="alert alert-danger" role="alert">

          <div class="alert-body">
            <?php echo e(Session::get('exper_deleted')); ?>

          </div>
        </div>


        <?php elseif(Session::has('exper_updated')): ?>
        <div class="alert alert-success" role="alert">

          <div class="alert-body">
            <?php echo e(Session::get('exper_updated')); ?>

          </div>
        </div>

        <?php endif; ?>





        <!-- Modal -->

        <div class="table table-responsive">
          <table class="table table-bordered" id="expert_list">
            <thead>
              <tr>
                <th>
                  #
                </th>
                <th>Expert Name</th>

                <th>Image</th>
                <th>Designation</th>
                <th>Quotes</th>
                <th>Intro Link</th>

                <th>Actions</th>
              </tr>
            </thead>
            <tbody>

              <?php $__currentLoopData = $experts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>

                <td><?php echo e($loop->index+1); ?></td>
                <td>

                  <span class="font-weight-bold"><?php echo e($row->expert_name); ?></span>
                </td>


                <td>

                  <div class="avatar-group">
                    <div
                      data-toggle="tooltip"
                      data-popup="tooltip-custom"
                      data-placement="top"
                      title=""
                      class="avatar pull-up my-0"
                      data-original-title=""
                    >
                      <img
                        src="<?php echo e(asset("storage/experts/$row->expert_image")); ?>"
                        alt="image"
                        height="50"
                        width="50"

                      />
                    </div>


                  </div>
                </td>
                <td>

                  <span class="font-weight-bold"><?php echo e($row->designation); ?> </span>
                </td>

                <td><?php echo $row->Quotes; ?> </td>
                <td>
                <?php echo e($row->intro_link); ?></td>




                <td>
                  <a href="#"><i class="fas fa-file-upload"></i></a>
                  <a href="#" data-toggle="modal" data-target="#ClassroomCourseEditModal" ><i class="fas fa-edit"></i></a>

                  <a id="delete" href="/admin/experts/delete/<?php echo e($row->id); ?>"><i class="fas fa-trash"></i></a>


                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>
        </div>

      </div>
    </div>
  </div>

</div>
<script>
  $(function(){
    'use strict';

    $('#expert_list').DataTable({
      responsive: true,
      language: {
        searchPlaceholder: 'Search...',
        sSearch: '',
        lengthMenu: '_MENU_ ',
      }
    });


  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\globalskills.com.bd\resources\views/backend/pages/experts/manage.blade.php ENDPATH**/ ?>