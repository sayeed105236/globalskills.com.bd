


<?php $__env->startSection('admin_dashboard_content'); ?>






<div class="container-fluid">
  <div class="db-breadcrumb">
    <h4 class="breadcrumb-title">Certificate Request</h4>
    <ul class="db-breadcrumb-list">
      <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-home"></i>Home</a></li>
      <li>User</li>
    </ul>
  </div>

  <!-- Card -->

  <div class="row" id="basic-table">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Certificate request Lists</h4>

        </div>


        <!-- Modal -->

        <div class="table table-responsive">
          <table id="certificate" class="table table-bordered">
            <thead>
              <tr>
                <th>No</th>
                <th>Name</th>

                <th>Email</th>

                <th>Phone Number</th>
                <th>Course Name</th>
                <th>Course Type</th>
                <th>Total hours</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Reason for participation:</th>
                <th>Trainer’s competence Review</th>
                <th>Training presentation material Review</th>
                <th>Course material Review</th>
                <th>Usefulness of the training</th>
                <th>Experience about training and exam booking</th>
                <th>Overall satisfaction in this training </th>
                <th>Status</th>
                <th>Action</th>


              </tr>
            </thead>
            <tbody>

              <?php $__currentLoopData = $certificate_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td><?php echo e($loop->index+1); ?></td>
                <td>
                    <?php echo e($row->name); ?>


                </td>
                <td><?php echo e($row->email); ?></td>

                <td><?php echo e($row->phone); ?></td>

                <td>
                    <?php echo e($row->classroom_course->classroom_course_title); ?>

                </td>
                <td>
                    <?php echo e($row->classroom_course->main_category->mcategory_title); ?>

                </td>
                <td><?php echo e($row->total_hours); ?></td>
                <td>
                <?php echo e($row->start_date); ?>



                </td>

                <td><?php echo e($row->end_date); ?></td>
                <td>
                  <?php echo e($row->reason); ?>

                </td>
                <td><?php echo e($row->trainers_competence); ?></td>
                <td><?php echo e($row->presentation); ?></td>
                <td><?php echo e($row->material); ?></td>
                <td><?php echo e($row->usefullness); ?></td>
                <td><?php echo e($row->experience); ?></td>
                <td><?php echo e($row->satisfaction); ?></td>
                <td>

                <span class="badge badge-pill badge-success"><?php echo e($row->status); ?></span>
                <?php if($row->status=='pending'): ?>
                <a href="<?php echo e(url('/admin/certificate-request-approve/'.$row->id)); ?>" class="btn btn-sm btn-primary">Approve Now</a>
                <?php endif; ?>
                </td>
                <td>
                  <a  href="#"><i class="fas fa-envelope-open-text"></i></a>
                    <a  href="/admin/home/download-pdf/<?php echo e($row->id); ?>"><i class="fas fa-file-pdf"></i></a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>

      </div>
    </div>
  </div>

</div>

<script>
  $(function(){
    'use strict';

    $('#certificate').DataTable({
      responsive: false,
      language: {
        searchPlaceholder: 'Search...',
        sSearch: '',
        lengthMenu: '_MENU_ ',
      }
    });


  });
</script>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\globalskills.com.bd\resources\views/backend/pages/certificate_request.blade.php ENDPATH**/ ?>