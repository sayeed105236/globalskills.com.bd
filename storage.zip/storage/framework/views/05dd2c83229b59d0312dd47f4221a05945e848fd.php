


<?php $__env->startSection('admin_dashboard_content'); ?>






<div class="container-fluid">
  <div class="db-breadcrumb">
    <h4 class="breadcrumb-title">Our Accreditation</h4>
    <ul class="db-breadcrumb-list">
      <li><a href="<?php echo e(route('admin.home')); ?>"><i class="fa fa-home"></i>Home</a></li>
      <li>Our Accreditation</li>
    </ul>
  </div>
  <!-- Card -->

  <div class="row" id="basic-table">
    <div class="col-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Our Accreditation</h4>
          <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#AccreditationAddModal"><i class="fas fa-plus-circle"></i></a>
            <?php echo $__env->make('backend.modals.accreditationaddmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php if(Session::has('accreditation_added')): ?>
        <div class="alert alert-success" role="alert">

          <div class="alert-body">
            <?php echo e(Session::get('accreditation_added')); ?>

          </div>
        </div>

        <?php elseif(Session::has('accreditation_deleted')): ?>
        <div class="alert alert-danger" role="alert">

          <div class="alert-body">
            <?php echo e(Session::get('accreditation_deleted')); ?>

          </div>
        </div>

        <?php endif; ?>


        <!-- Modal -->

        <div class="table table-responsive">
          <table class="table table-bordered" id="course_table">
            <thead>
              <tr>
                <th>ID</th>
                <th>
                  Name
                </th>
                <th>Images</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $accreditations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td><?php echo e($row->id); ?></td>

                <td><?php echo e($row->name); ?></td>

                <td>
                  <div class="avatar-group">
                    <div
                      data-toggle="tooltip"
                      data-popup="tooltip-custom"
                      data-placement="top"
                      title=""
                      class="avatar pull-up my-0"
                      data-original-title=""
                    >
                      <img
                        src="<?php echo e(asset("storage/Accreditation/$row->accreditation_image")); ?>"
                        alt="image"
                        height="50"
                        width="50"

                      />
                    </div>


                  </div>





                </td>


                <td>


                  <a id="delete" href="/admin/home/accreditation/delete/<?php echo e($row->id); ?>"><i class="fas fa-trash"></i></a>

                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>
        </div>

      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\globalskills.com.bd\resources\views/backend/pages/accreditation.blade.php ENDPATH**/ ?>